package Experiments;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.getProperties().list(System.out);
		String name = System.getProperty("user.name");
		System.out.print(name);
		
	}

}
