package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

import pageobjects.HomePage1;
import pageobjects.LoginPage1;

public class Base {
	
	public Properties prop;
	
	public void loadPropertiesFile() throws IOException {
		
		prop = new Properties();
		
		File propFile = new File(System.getProperty("user.dir")+"\\src\\test\\resources\\data.properties");
		
		FileInputStream fis = new FileInputStream(propFile);
		
		prop.load(fis);
		
	}
	public LoginPage1 initialiseLogin(WebDriver driver) {
		
		LoginPage1 loginPage = new LoginPage1(driver);
		return loginPage;
	}
	
	
	public HomePage1 initialiseHome(WebDriver driver) {
		
		HomePage1 homePage = new HomePage1(driver);
		return homePage;
	}
	
	@SuppressWarnings("null")
	public WebDriver Current(ArrayList<String> wib,WebDriver driver)
	{
		
		driver.switchTo().window(wib.get(1));
		return driver;
		
	}
	public WebDriver openBrowser(String browserName){
		
		WebDriver driver = null;
		
		if(browserName.equals("chrome")) {
			ChromeOptions options = new ChromeOptions();
	    	options.addArguments("--disable-notifications");
			
			driver = new ChromeDriver(options);
			
		}else if(browserName.equals("firefox")) {
			
			driver = new FirefoxDriver();
			
		}else if(browserName.equals("edge")) {
			
			driver = new EdgeDriver();
			
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		return driver;
		
		
	}
	
	public String generateTimeStamp() {
		
		Date date = new Date();
		
		return date.toString().replace(" ","_").replace(":","_");
		
	}
	
	public String captureScreenshot(WebDriver driver,String testName) {
		
		File srcScreenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String destFilePath = System.getProperty("user.dir")+"\\Screenshots\\"+testName+".png";
		File destScreenshotFile = new File(destFilePath);
		try {
			FileHandler.copy(srcScreenshotFile, destScreenshotFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return destFilePath;
	}
	
	

}
