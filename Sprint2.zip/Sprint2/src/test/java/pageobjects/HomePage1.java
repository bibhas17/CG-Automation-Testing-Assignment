package pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage1 {
	WebDriver driver;
	
	public HomePage1(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "11700")
	private WebElement select1Bhk;
	
	@FindBy(xpath = "(//div[@class='mb-search__title'])[1]")
	private WebElement flatBhk;
	
	@FindBy(xpath = "(//a[@class='mb-header__main__link js-menu-link'])[1])")
	private WebElement locationHeading;
	
	@FindBy(xpath = "//span[normalize-space()='adityapur, jamshedpur']")
	private WebElement searchSuggest;
	
	@FindBy(xpath = "//div[@class='mb-searcg_auto-suugest_item'][1]")
	private WebElement locationOne;
	
	@FindBy(xpath = "//div[@class='mb-search__tag-close']")
	private WebElement closeLocation;
	
	@FindBy(xpath = "//div[@class='prime-pack__intro__icon-crown']")
	private WebElement crownLogo;
	
	
	@FindBy(xpath = "//a[text() = 'Join Now']")
	private WebElement joinButton;
	
	@FindBy(linkText = "MB Prime")
	private WebElement mbPrimeButton;
	
	@FindBy(xpath = "//a[normalize-space()='Edit Requirement']")
	private WebElement successfullSearch;
	
	@FindBy(id = "location-error-id")
	private WebElement loactionError;
	
	@FindBy(id = "keyword")
	private WebElement enterLoaction;
	
	@FindBy(xpath = "//div[@class='mb-search__btn']")
	private WebElement homeSearchButton;
	
	@FindBy(xpath = "//div[@class='mb-search__tag-t']")
	private WebElement defaultLocationOption;
	
	@FindBy(xpath = "//a[normalize-space()='Sign Up']")
	private WebElement Signupoption;
	
	@FindBy(xpath="(//a[text()='Login'])[1]")
	private WebElement loginMainAccount;
	
	@FindBy(xpath="(//a[text()='Login'])[2]")
	private WebElement loginSelectOption;
	
	@FindBy(xpath="//a[@href=\"javascript:ppPopupClose('PostPropLandingPopup')\"]")
	private WebElement crossDialogBox;
	
	@FindBy(xpath = "(//span[@class='font-type-4'])[2]")
	private WebElement successfullLoginMessage;
	
	public WebElement initialiseLoginMenu() {
		return loginMainAccount;
	}
	public WebElement initialiseLoginInsideOption() {
		return loginSelectOption;
	}
	
	public void clickOnLoginOption() {
		
		
		loginMainAccount.click();
	}
	
	public void crossDialogBoxMethod() {
		 crossDialogBox.click();
		
	}
	
	
	public String messageSuccessfuldisplay() {
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	    WebElement headingElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='font-type-4'])[2]")));
	    String heading = headingElement.getText();
	    
	    wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    return (heading);
	    

	}
	public void selectLoginOption() {
		// TODO Auto-generated method stub
		loginSelectOption.click();
	}
	
	public void selectSignupOption() {
		
		Signupoption.click();
		
	}
	
	public void unselectDefaultlocation() {
		defaultLocationOption.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		closeLocation.click();
	}
	public void selectHomeSearchButton() {
		homeSearchButton.click();
	}
	
	public void enterLocationField(String location) {
		
		enterLoaction.sendKeys(location);
	}
	
	public boolean loactionErrorMessage() {
		return loactionError.isDisplayed();
		
	}
	
	public boolean sucessfullSearchMsg() {
		return successfullSearch.isDisplayed();
	}
	
	public void selectPrimeOption() {
		mbPrimeButton.click();
		//System.out.println(mbPrimeButton.isDisplayed());
	}
	
	public void selectJoinButton() {
		joinButton.click();
		//System.out.println("join  "+joinButton.isDisplayed());
	}
	public boolean crownLogoDisplayed() {
		return crownLogo.isDisplayed();
	}
	
	public void selectCloseLocation() {
		closeLocation.click();
	}
	
	public void selectLocation() {
		locationOne.click();
	}
	
	public void selectSuggestButton() {
		searchSuggest.click();
	}
	
	public void selectLocationSettings() {
		locationHeading.click();
	}
	public void selectFlatBhkField() {
		
	}
	
	public void select1BhkOption() {
		select1Bhk.click();
	}
	
	@FindBy(id = "10002_10003_10021_10022")
	private WebElement selectFlatCategory;
	
	public void selectFlatCatgry() {
		selectFlatCategory.click();
	}
	
	
	
	

}
