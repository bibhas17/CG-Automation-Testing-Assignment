package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage1 {
	
	WebDriver driver;
	
	public LoginPage1(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	@FindBy(id="step1Error")
	private WebElement emptyEmailMessage;
	
	@FindBy(id="pass_err")
	private WebElement passworderror;
	
	@FindBy(xpath = "//input[@id='emailOrMobile']")
	private WebElement emailAddressField;
	
	@FindBy(xpath = "//input[@id='password']")
	private WebElement passwordField; 
	
	@FindBy(id="btnStep1")
	private WebElement nextButton;
	
	@FindBy(xpath = "//div[@id='step1Error']")
	private WebElement errorInEmailMessage;
	
	@FindBy(id = "btnLogin")
	private WebElement loginButton;
	
	public void enterEmailAddress(String emailText) {
		emailAddressField.sendKeys(emailText);
			
	}
	
	public void selectNextButton() {
		nextButton.click();
	}
	
	public void enterPassword(String pass) {
		passwordField.sendKeys(pass);
	}
	
	public void clickOnLoginButton() {
		loginButton.click();
	}
	
	public boolean emailErrorMessageDisplayed() {
		return errorInEmailMessage.isDisplayed();
		
	}
	
	
	public boolean passwordErrorMessageDisplayed() {
		return passworderror.isDisplayed();
		
	}
	
	

}
