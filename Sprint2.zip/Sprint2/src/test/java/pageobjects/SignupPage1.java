package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPage1 {
	WebDriver driver;
	
		public SignupPage1(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
		
		
		@FindBy(id="emailErr")
		private WebElement duplicateEmailMsg;
		
		@FindBy(id = "mobilelErr1")
		private WebElement duplicatenumberMsg;
		
		@FindBy(id= "ubifname.errors")
		private WebElement erroMessage;
		
		@FindBy(xpath = "//label[contains(text(),'I agree to Magicbricks')]")
		private WebElement tcbox;
		
		@FindBy(id = "ubimobile1")
		private WebElement mobileField;
		
		@FindBy(id = "ubipass")
		private WebElement signupPassword;
		
		@FindBy(id = "ubiemail")
		private WebElement signupEmailField;
		
		@FindBy(xpath = "//input[@id='ubifname']")
		private WebElement nameInputField;
		
		@FindBy(xpath = "//label[text()='Buyer/Owner']")
		private WebElement checkBoxBuyer;
		
		@FindBy(xpath = "//button[normalize-space()='Sign Up']")
		private WebElement signupButton;
		
		@FindBy(id = "termsAndConditions.errors")
		private WebElement tcErrorfield;
		
		public void clickSignupButton() {
			signupButton.click();
		}
		
		public void enterMobileNumber(String number) {
			mobileField.sendKeys(number);
		}
		
		public void enterPassword(String pass) {
			signupPassword.sendKeys(pass);
		}
		
		public void enterEmailField(String email) {
			signupEmailField.sendKeys(email);
			
		}
		
		public void enterNameField(String name) {
			nameInputField.sendKeys(name);
		}
		
		public boolean errorMessageCompulsoryDisplayed() {
			
			return erroMessage.isDisplayed();
		}
		
		public boolean duplicateMobileMessage() {
			return duplicatenumberMsg.isDisplayed();
		}
		
		public boolean duplicateEmailMessage() {
			return duplicateEmailMsg.isDisplayed();
		}
		
		public void selectCheckbox() {
			checkBoxBuyer.click();
		}
		
		public void selectTermConditionBox() {
			tcbox.click();
		}
		
		public boolean errorMessageTermsCondition() {
			return tcErrorfield.isDisplayed();
			
		}
		
		

}
