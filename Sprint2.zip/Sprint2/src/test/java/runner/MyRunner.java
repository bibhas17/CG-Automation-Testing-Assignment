package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(plugin= {"html:target/cucumber_html_report.html"},
		features=  {"src/test/java/feature"},
	glue = "stepDefinitions")
public class MyRunner extends AbstractTestNGCucumberTests {

}
