package stepDefinitions;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import base.Base;
import io.cucumber.java.After;
import io.cucumber.java.en.*;
import pageobjects.HomePage1;
import pageobjects.LoginPage1;

public class HomePage extends Base {
	WebDriver driver ;
	LoginPage1 loginPage;
	HomePage1 homePage;
	
	@After("@homePage")
	public void tearDown() {
		
		driver.quit();
	}

	@Given("^User has opened the homePage$")
	public void user_has_opened_the_homepage() throws Throwable {
		loadPropertiesFile();
		driver = openBrowser(prop.getProperty("browserName"));
		driver.get(prop.getProperty("url"));
		
		homePage = new HomePage1(driver);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@When("^User clicks on search button$")
	public void user_clicks_on_search_button() throws Throwable {
		homePage = new HomePage1(driver);
		homePage.unselectDefaultlocation();

		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
		homePage.selectHomeSearchButton();

	}

	@Then("^User is not able to view diffrent property$")
	public void user_is_not_able_to_view_diffrent_property() throws Throwable {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		Assert.assertTrue(homePage.loactionErrorMessage());

	}
	@When("User enters valid prefered locations as Clicks on Search button")
	public void user_enters_valid_prefered_locations_as_clicks_on_search_button() {
		homePage = new HomePage1(driver);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		homePage.selectFlatBhkField();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		homePage.selectFlatCatgry();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		homePage.select1BhkOption();
		//homePage.enterLocationField("adityapur, jamshedpur");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//mhomePage.selectSuggestButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		homePage.selectHomeSearchButton();
	}


//	@When("^User enters valid prefered locations as (.+)  Clicks on Search button$")
//	public void user_enters_valid_prefered_locations_as_clicks_on_search_button(String location) throws Throwable {
//		homePage = new HomePage1(driver);
//		homePage.unselectDefaultlocation();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		homePage.selectLocation();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		homePage.selectHomeSearchButton();
//
//	}

	@Then("^User should see prefered locations$")
	public void user_should_see_prefered_locations() throws Throwable {
		Assert.assertTrue(homePage.sucessfullSearchMsg());
	}
	
	
	@When("User clicks on the join option")
	public void user_clicks_on_the_join_option() throws InterruptedException {
		
		Thread.sleep(3000);
		homePage.selectJoinButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));

	}

	@Then("^User should be able to view and join subscription page$")
	public void user_should_be_able_to_view_and_join_subscription_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Assert.assertTrue(homePage.crownLogoDisplayed());
	}

	@And("^Navigated to mb prime option$")
	public void navigated_to_mb_prime_option() throws Throwable {
		Thread.sleep(3000);
		homePage.selectPrimeOption();
		Thread.sleep(3000);
		
		
	}
	
	

}
