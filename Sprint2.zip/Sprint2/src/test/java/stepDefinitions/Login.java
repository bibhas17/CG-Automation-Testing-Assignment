package stepDefinitions;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;

import pageobjects.HomePage1;
import pageobjects.LoginPage1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base.Base;
import io.cucumber.java.After;
import io.cucumber.java.en.*;

public class Login extends Base {
	WebDriver driver ;
	LoginPage1 loginPage;
	HomePage1 homePage;
	
	@After("@login")
	public void tearDown() {
		
		driver.quit();
	}
	
	@Given("^User has opened the Application URL$")
	public void user_has_opened_the_application_url() throws IOException {

		loadPropertiesFile();
		driver = openBrowser(prop.getProperty("browserName"));
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));

	}

	@And("^Navigated to Login page$")
	public void navigated_to_login_page() throws InterruptedException {
	

		Thread.sleep(3000);
	    homePage = initialiseHome(driver);
		homePage.clickOnLoginOption();
		Thread.sleep(3000);
		homePage.selectLoginOption();
		Thread.sleep(3000);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));

	    loginPage = initialiseLogin(driver);

	}

	@When("^User enters valid email and valid password into the fields$")
	public void user_enters_valid_email_and_valid_password_into_the_fields() {
//	    	LoginPage1 loginPage = new LoginPage1(driver);
		loginPage.enterEmailAddress(prop.getProperty("validEmail"));
		loginPage.selectNextButton();
		loginPage.enterPassword(prop.getProperty("validpassword"));

	}

	@And("^Clicks on Login button$")
	public void clicks_on_login_button() {
		loginPage.clickOnLoginButton();
	}

	@Then("^User should be able to login successful$")
	public void user_should_be_able_to_login_successful() {

//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		WebElement headingElement = wait
//				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='font-type-4'])[2]")));
//		//String heading = headingElement.getText();
//		// System.out.println(heading);
//		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String value = homePage.messageSuccessfuldisplay();
		boolean result = value.equals(prop.getProperty("successfulLoginMessage"));
		Assert.assertTrue(result);
		homePage.crossDialogBoxMethod();
		

	}

	@When("^User enter invalid email and valid password into the fields$")
	public void user_enter_invalid_email_and_valid_password_into_the_fields() {

		loginPage.enterEmailAddress("amootri" + generateTimeStamp() + "@gmail.com");

	}

	@And("^Clicks on next button$")
	public void clicks_on_next_button() throws Throwable {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
	}

	@Then("^User should see a warning message of wrong email$")
	public void user_should_see_a_warning_message_of_wrong_email() throws Exception {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Assert.assertTrue(loginPage.emailErrorMessageDisplayed());
		
	}

	@When("^User enter valid email and invalid pasword into the fields$")
	public void user_enter_valid_email_and_invalid_pasword_into_the_fields() {
		loginPage.enterEmailAddress(prop.getProperty("validEmail"));
		loginPage.selectNextButton();
		loginPage.enterPassword(prop.getProperty("invalidpasswords"));

	}

	@When("^User dont enter email and password into the fields$")
	public void user_dont_enter_email_and_password_into_the_fields() throws Throwable {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.enterEmailAddress("");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
	}

	@Then("^User should see a warning message of wrong password$")
	public void user_should_see_a_warning_message_of_wrong_password() {

		Assert.assertTrue(loginPage.passwordErrorMessageDisplayed());
		
	}

}
