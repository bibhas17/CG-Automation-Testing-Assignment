package stepDefinitions;

import java.time.Duration;
import java.util.ArrayList;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import base.Base;
import io.cucumber.java.After;
import io.cucumber.java.en.*;
import pageobjects.HomePage1;
import pageobjects.SignupPage1;


public class Signup extends Base {
	WebDriver driver ;
	SignupPage1 signup;
	HomePage1 homepage;

	@After("@Signup")
	public void tearDown() {
		
		driver.quit();
	}

	    @Given("^User has opened the application URL$")
	    public void user_has_opened_the_application_url() throws Throwable {
	    	loadPropertiesFile();
			driver = openBrowser(prop.getProperty("browserName"));
			driver.get(prop.getProperty("url"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
	    }
	    
	    
	    @And("^Navigated to Signup page$")
	    public void navigated_to_signup_page() throws Throwable {
	    
	    	Thread.sleep(3000);
	       homepage = new HomePage1(driver);
	       homepage.clickOnLoginOption();
	       Thread.sleep(5000);
	       homepage.selectSignupOption();
	       Thread.sleep(3000);
	       ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
		   driver.switchTo().window(wid.get(1));
		   signup = new SignupPage1(driver);
	    }
	    
	    @And("^Clicks on signup button$")
	    public void clicks_on_signup_button() throws Throwable {
	    	 signup.clickSignupButton();
	    }
	    
	    @Then("^Error should be displayed to enter value$")
	    public void error_should_be_displayed_to_enter_value() throws Throwable {
	       Assert.assertTrue(signup.errorMessageCompulsoryDisplayed());
	    }
	    
	    @When("^User enters all the fields as (.+) (.+) (.+)(.+)$")
	    public void user_enters_all_the_fields_as(String name, String email, String password, String mobile) throws Throwable {
	    	 signup.selectCheckbox();
	    	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    	 signup.enterNameField(name);
	    	 
	    	 signup.enterEmailField(email);
	    	 signup.enterPassword(password);
	    	 signup.enterMobileNumber(mobile);
	    	 signup.clickSignupButton();
	    
	    }
	    
//	    @When("^User enters all the fields as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
//	    public void user_enters_all_the_fields_as_something_something_something_something(String name, String email, String password, String mobile, String strArg1, String strArg2, String strArg3, String strArg4) throws Throwable {
//	    	signup.selectCheckbox();
//	    	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//	    	 signup.enterNameField(name);
//	    	 
//	    	 signup.enterEmailField(email);
//	    	 signup.enterPassword(password);
//	    	 signup.enterMobileNumber(mobile);
//	    	 signup.clickSignupButton();
//	    }

	    
//	    @When("^User enters all the fields$")
//	    public void user_enters_all_the_fields() throws Throwable {
//	        signup.selectCheckbox();
//	        Thread.sleep(3000);
//	        signup.enterNameField(prop.getProperty("Username"));
//	        
//	        signup.enterEmailField(prop.getProperty("validEmail"));
//	        signup.enterPassword(prop.getProperty("validpassword"));
//	        signup.enterMobileNumber("6206112121");
//	        signup.selectTermConditionBox();
//	        signup.clickSignupButton();
//	        
//	        
//	    }
//
	    
	    @When("User enters duplicate email address")
	    public void user_enters_duplicate_email_address() throws InterruptedException {
	    	Thread.sleep(3000);	    	
	    	signup.enterEmailField(prop.getProperty("duplicateEmail"));
	    	signup.clickSignupButton();
	    }
	    
	    @Then("^Error about existing email should be displayed$")
	    public void error_about_existing_email_should_be_displayed() throws Throwable {
	    	Assert.assertTrue(signup.duplicateEmailMessage());
	    }


//	    @When("^User enters duplicate email address $")
//	    public void user_enters_duplicate_email_address() throws InterruptedException  {
//	    	Thread.sleep(3000);
//	    	signup.enterEmailField(prop.getProperty("duplicateEmail"));
//	    	
//	    }
	       	    

	    @When("^User enters duplicate phn number in mobile field$")
	    public void user_enters_duplicate_phn_number_in_mobile_field() throws Throwable {
	        signup.enterMobileNumber(prop.getProperty("duplicateMobileNumber"));
	    }

	    @Then("^User account should be created successfully$")
	    public void user_account_should_be_created_successfully() throws Throwable {
	        System.out.println("hello");
	    }

	    

	   
	    @Then("^Error about duplicate number should be displayed$")
	    public void error_about_duplicate_number_should_be_displayed() throws Throwable {
	        Assert.assertTrue(signup.duplicateMobileMessage());
	    }

	    @Then("^No input field should be displayed again$")
	    public void no_input_field_should_be_displayed_again() throws Throwable {
	      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	      Assert.assertTrue(signup.errorMessageTermsCondition());
	    }

	   

	   

	    @And("^Does not click on T_C Box$")
	    public void does_not_click_on_tc_box() throws Throwable {
	    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    	signup.selectTermConditionBox();
	    }

}
