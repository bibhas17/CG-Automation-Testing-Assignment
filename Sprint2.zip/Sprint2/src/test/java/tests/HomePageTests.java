package tests;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.Base;

import pageobjects.HomePage1;

public class HomePageTests extends Base {
public WebDriver driver;
	
	@AfterMethod
	public void tearDown() {
		
		driver.quit();
		
	}
	
	@BeforeMethod
	public void setup() throws IOException {
		
		loadPropertiesFile();
		driver = openBrowser(prop.getProperty("browserName"));
		driver.get(prop.getProperty("url"));
		
	}
	@Test
	public void searchWithoutValues() {
		HomePage1 homePage = new HomePage1(driver);
		homePage = new HomePage1(driver);
		homePage.unselectDefaultlocation();

		
		homePage.selectHomeSearchButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		Assert.assertTrue(homePage.loactionErrorMessage());
	}
	@Test
	public void joinMBPrime()throws Exception {
		HomePage1 homePage = new HomePage1(driver);
		Thread.sleep(2000);
		homePage.selectPrimeOption();
		Thread.sleep(3000);
		homePage.selectJoinButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Assert.assertTrue(homePage.crownLogoDisplayed());
	    
		
	}
	

}
