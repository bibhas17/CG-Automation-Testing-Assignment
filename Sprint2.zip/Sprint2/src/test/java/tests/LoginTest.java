package tests;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import base.Base;

import pageobjects.HomePage1;

import pageobjects.LoginPage1;
import utils.ExcelReader;

public class LoginTest extends Base {
	
	public WebDriver driver;
	
	@AfterMethod
	public void tearDown() {
		
		driver.quit();

	}
	@BeforeMethod
	public void setup() throws IOException {
		
		loadPropertiesFile();
		driver = openBrowser(prop.getProperty("browserName"));
		driver.get(prop.getProperty("url"));
		
	}
	@Test(dataProvider = "dataSupplier")
	public void loginWithValidCredentials(String email,String password) throws InterruptedException {
		
		HomePage1 homePage = new HomePage1(driver);
		Thread.sleep(3000);
		homePage.clickOnLoginOption();
		Thread.sleep(3000);
		homePage.selectLoginOption();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));
	    LoginPage1 loginPage = new LoginPage1(driver);
	    loginPage.enterEmailAddress(email);
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.enterPassword(password);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.clickOnLoginButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String value = homePage.messageSuccessfuldisplay();
		boolean result = value.equals(prop.getProperty("successfulLoginMessage"));
		Assert.assertTrue(result);
		homePage.crossDialogBoxMethod();
		
		
	}
	
	@DataProvider
	public Object[][] dataSupplier() throws Exception {
		
		Object[][] data = ExcelReader.readDataFromExcelFile();
		return data;
		
		
		
		
		//Object[][] data = {{"jhabibhas007@gmail.com","zzx7tb49VD!N&$"},{"xsecond@gmail.com","zzx7tb49VD!N&"}};
		//return data;
		
	}
	
	@Test
		public void loginWithInvalid() throws InterruptedException {
		
		HomePage1 homePage = new HomePage1(driver);
		Thread.sleep(3000);
		homePage.clickOnLoginOption();
		Thread.sleep(3000);
		homePage.selectLoginOption();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));
	    LoginPage1 loginPage = new LoginPage1(driver);
	    loginPage.enterEmailAddress("amootri" + generateTimeStamp() + "@gmail.com");
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Assert.assertTrue(loginPage.emailErrorMessageDisplayed());
	

	    
		
	}
	
	@Test
	public void loginWithValidEmailAndInvalidPassword() throws InterruptedException {
		
		HomePage1 homePage = new HomePage1(driver);
		Thread.sleep(3000);
		homePage.clickOnLoginOption();
		Thread.sleep(3000);
		homePage.selectLoginOption();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));
	    LoginPage1 loginPage = new LoginPage1(driver);
	    loginPage.enterEmailAddress(prop.getProperty("validEmail"));
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.enterPassword(prop.getProperty("invalidpasswords"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.clickOnLoginButton();
		Assert.assertTrue(loginPage.passwordErrorMessageDisplayed());
		
		
	}
		@Test
        public void loginWithoutProvidingAnyCredentials() throws InterruptedException {
		
		HomePage1 homePage = new HomePage1(driver);
		Thread.sleep(3000);
		homePage.clickOnLoginOption();
		Thread.sleep(3000);
		homePage.selectLoginOption();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(wid.get(1));
	    LoginPage1 loginPage = new LoginPage1(driver);
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.enterEmailAddress("");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginPage.selectNextButton();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Assert.assertTrue(loginPage.emailErrorMessageDisplayed());
	

}
}
