package tests;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.Base;
import pageobjects.HomePage1;
import pageobjects.SignupPage1;

public class SignupTest extends Base {

	public WebDriver driver;

	@AfterMethod
	public void tearDown() {

		driver.quit();

	}

	@BeforeMethod
	public void setup() throws IOException {

		loadPropertiesFile();
		driver = openBrowser(prop.getProperty("browserName"));
		driver.get(prop.getProperty("url"));

	}

	@Test(priority=1)

	public void signupWithoutFillingAnyFieds() throws InterruptedException {
		Thread.sleep(3000);
		HomePage1 homepage = new HomePage1(driver);
		homepage.clickOnLoginOption();
		Thread.sleep(5000);
		homepage.selectSignupOption();
		Thread.sleep(3000);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		SignupPage1 signup = new SignupPage1(driver);
		signup.clickSignupButton();
		Assert.assertTrue(signup.errorMessageCompulsoryDisplayed());

	}
	
	@Test(priority=2)
	public void signUpWithDuplicateNumber() throws InterruptedException {
		Thread.sleep(3000);
		HomePage1 homepage = new HomePage1(driver);
		homepage.clickOnLoginOption();
		Thread.sleep(5000);
		homepage.selectSignupOption();
		Thread.sleep(3000);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		SignupPage1 signup = new SignupPage1(driver);
	
		signup.enterMobileNumber(prop.getProperty("duplicateMobileNumber"));
		signup.clickSignupButton();
		Assert.assertTrue(signup.duplicateMobileMessage());

	}
	
	@Test(priority=3)
	public void signUpWithDuplicateEmail() throws InterruptedException {
		Thread.sleep(3000);
		HomePage1 homepage = new HomePage1(driver);
		homepage.clickOnLoginOption();
		Thread.sleep(5000);
		homepage.selectSignupOption();
		Thread.sleep(3000);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		SignupPage1 signup = new SignupPage1(driver);
		Thread.sleep(3000);	    	
    	signup.enterEmailField(prop.getProperty("duplicateEmail"));
    	signup.clickSignupButton();
		
    	Assert.assertTrue(signup.duplicateEmailMessage());
		
	}
	
	@Test(priority=4)
	
	public void signUpWithoutTerms() throws InterruptedException {
		Thread.sleep(3000);
		HomePage1 homepage = new HomePage1(driver);
		homepage.clickOnLoginOption();
		Thread.sleep(5000);
		homepage.selectSignupOption();
		Thread.sleep(3000);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		SignupPage1 signup = new SignupPage1(driver);
		
		 signup.selectCheckbox();
    	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    	 signup.enterNameField(prop.getProperty("Username"));
    	 
    	 signup.enterEmailField(prop.getProperty("Email2"));
    	 signup.enterPassword(prop.getProperty("validpassword"));
    	 signup.enterMobileNumber(prop.getProperty("SecondMobileNumber"));
    	 signup.clickSignupButton();
    	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     Assert.assertTrue(signup.errorMessageTermsCondition());
	}

}
